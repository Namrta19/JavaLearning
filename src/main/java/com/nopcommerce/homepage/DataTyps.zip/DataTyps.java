package com.nopcommerce.homepage;

public class DataTyps {
    public static void main(String[] args) {
        int num1=127;
        int num2=128;

        System.out.println("num1:" + num1);
        System.out.println("num2:" + num2);
    }
}
