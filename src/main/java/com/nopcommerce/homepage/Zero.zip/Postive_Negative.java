package com.nopcommerce.homepage;

public class Postive_Negative
{
    public static void main(String[] args)
    {
        int number=109;
        if(number>0)
        {   System.out.println("number+ is a positive number");
        }
        else if (number < 0 ) {
            System.out.println("number+ is a nagative number");
        }


    }


}
