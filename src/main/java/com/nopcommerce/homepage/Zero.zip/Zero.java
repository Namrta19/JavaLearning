package com.nopcommerce.homepage;
// use if else else if

public class Zero {
    public static void main(String[] args) {
        int nm=1;
        int nm1=-1;

        if (nm > nm1) {
            System.out.println("1 is positive");
        }
        else if (nm<nm1) {
            System.out.println("-1 is negative");
        }
        else {
            System.out.println("number is zero");
        }
    }
}
