package com.nopcommerce.homepage;

public class Arithmetic
{ public static void main(String[] args) {

    int a = 12;
    int b = 5;
    int result1;
    int result2;
    //addition operator
    System.out.println("a + b ="+(a+b));

    //subtraction opreratorA
    System.out.println("a - b ="+ (a-b));

    //multiplication oprerator
    System.out.println("a * b =" +(a*b));

    //division operator
    System.out.println("a / b =" +(a/b));

    //modulo operator
    System.out.println("a % b =" +(a%b));

    // increment oprator
    result1 = ++a;
    System.out.println("After increment: "+ a);

    // decrement operator
    result2 = --b;
    System.out.println("After decrement:" + b);




}
}
