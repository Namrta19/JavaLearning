package com.nopcommerce.homepage;

public class CheckEvenOdd {

    public static void main(String[] args) {
        int num = 78;
        int num1 = 77;
        if  (num % 2 == 0) ;
        //System.out.println("Enter number even");
        else
        System.out.println("enter number odd");
    }


}



