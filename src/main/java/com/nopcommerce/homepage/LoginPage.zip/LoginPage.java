package com.nopcommerce.homepage;

public class LoginPage {

    public static void main(String[] args) {

        System.out.println("My first Java Program");

    }
}
