package JavaBasic;

public class WhileLoopTables {
    public static void main(String[] args) {
        int n = 1;
        int m = 9;
        System.out.println("Table of 9");

        //for(int i=1; i<=18; ++k) {


        while (n <= 10)
        {
            System.out.println(m +"*" + n + "=" + (m *n));
            n++;

        }
    }

}