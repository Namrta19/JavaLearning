package JavaBasic;

public class ForLoopEven {

    public static void main(String[] args) {

        int a = 10;

        for (int i = 0; i <= a;
        i++);
        
            if (a % 2 == 0);

                System.out.println(a + " ");
        }

    }










