package JavaBasic;

public class WhileLoopEven {
    public static void main(String[] args) {
        int j=0;
        int k=0;

        while(j<=5){
            System.out.println(k);
            j+=1;
            k+=2;

        }

    }
}
