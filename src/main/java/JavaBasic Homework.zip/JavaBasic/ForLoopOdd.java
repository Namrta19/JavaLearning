package JavaBasic;

public class ForLoopOdd {


        public static void main(String[]args) {

            int a =10;
            for (int i = 0; i<a; i++) {
                if(i % 2 != 0) {
                    System.out.print(i +" ");

                }
            }
        }

    }


