package JavaBasic;

public class DoWhileLoopEven {

    public static void main(String []args) {
        int j = 0;
     System.out.println("Even number");

     do{
         if (j  % 2== 0) {
             System.out.println(" " + j);
         }
         j++;
      }while (j<=20);
     }
}






