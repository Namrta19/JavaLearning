public class VotingAge {

    public static void main(String[] args)
    {
        int Age = 19;

                if (Age<18) {
                    System.out.println("Not Eligible to vote");
                }else if (Age>18) {
                    System.out.println("Eligible to vote");
                }
    }
}
