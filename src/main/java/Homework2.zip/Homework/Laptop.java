package Homework;

//class
public class Laptop {

    double height;
    double screenshot;
    int brightness;
    int modal;


    public static void main(String [] args){
        Laptop a = new Laptop();
        Laptop b = new Laptop();
         a.modal =  2019;
         b.modal = 2020;

         System.out.println(a.modal);
    }


    }



