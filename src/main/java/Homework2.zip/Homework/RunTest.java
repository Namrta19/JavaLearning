package Homework;

public class RunTest {

    public static void main(String [] args){
        Car c1 = new Car();
        c1.BMWcolour();

        Car c2 = new Car();
        c2.BMWyear();

        Plane P1 = new Plane();
        P1.BAmodal();

        Plane P2 = new Plane();
        P2.BAcolour();

    }
}
