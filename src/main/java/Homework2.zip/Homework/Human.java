package Homework;
// object
public class Human {
  public static void main(String []args){
      Earth details = new Earth();
 details.name  =  "my name is tom";
 details.age = 20;
 details.height = 5.8;


        System.out.println(details.height );

    }


    }

