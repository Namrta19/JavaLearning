package Homework;

public class Vehical {

    public void BMWspeed() {
        System.out.println("The speed is 60 Miles pr hr");
    }

    public void BMWyear() {
        System.out.println("The year 2018");
    }

    public void BMWcolour() {
        System.out.println("colour is white");
    }
    public void BAmodal() {
        System.out.println("BA modal is 707");
    }

    public void BAcolour() {
        System.out.println("colour is white & blue");
    }

}

