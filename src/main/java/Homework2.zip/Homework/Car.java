package Homework;

public class Car extends Vehical{
    @Override
    public void BMWyear() {
    System.out.println("The year 2015");
}


}
