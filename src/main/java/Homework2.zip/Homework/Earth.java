package Homework;

public class Earth {
    // public static void main(String [] args) {

    String name;
    int age;
    double height;


    //       tom= new Human();
    //       tom.age = 5;
    //       tom.eyeColour =  "Black";
    //       tom.name = "tom ";




    }

