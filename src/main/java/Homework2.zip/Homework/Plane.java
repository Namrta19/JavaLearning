package Homework;

public class Plane extends Vehical{

}
